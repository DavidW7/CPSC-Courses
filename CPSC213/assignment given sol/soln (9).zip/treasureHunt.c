//
// This is the solution to CPSC 213 Assignment 9.
// Do not share this code or any portion of it with anyone in any way.
// Do not remove this comment.
//

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/errno.h>
#include <assert.h>
#include "uthread.h"
#include "queue.h"
#include "disk.h"

queue_t pending_read_queue;
volatile int done;

void interrupt_service_routine() {
  void *val;
  void *arg;
  void (*callback)(void*, void*);
  queue_dequeue(pending_read_queue, &val, &arg, &callback);
  callback(val, arg);
}

/* forward declaration */
void handleOtherReads (void *resultv, void *countv);

static void doNextRead(void *resultv, void *countv) {
  int *resultp = resultv;
  int *countp = countv;
  if(*countp == 0) {
    done = 1;
  } else {
    queue_enqueue(pending_read_queue, resultp, countp, handleOtherReads);
    disk_schedule_read(resultp, *resultp);
  }
}

void handleOtherReads (void *resultv, void *countv) {
  int *countp = countv;
  (*countp)--;
  doNextRead(resultv, countv);
}

void handleFirstRead (void *resultv, void *countv) {
  int *resultp = resultv;
  int *countp = countv;
  /* set count for future reads */
  *countp = *resultp;
  /* pass pointers onwards (all pointers refer to main's result & count vars */
  doNextRead(resultv, countv);
}

int main (int argc, char** argv) {
  // Command Line Arguments
  static char* usage = "usage: treasureHunt starting_block_number";
  int starting_block_number;
  char *endptr;
  if (argc == 2)
    starting_block_number = strtol (argv [1], &endptr, 10);
  if (argc != 2 || *endptr != 0) {
    printf ("argument error - %s \n", usage);
    return EXIT_FAILURE;
  }

  // Initialize
  uthread_init (1);
  disk_start (interrupt_service_routine);
  pending_read_queue = queue_create();


  // Start the Hunt
  int result, count;
  queue_enqueue(pending_read_queue, &result, &count, handleFirstRead);
  disk_schedule_read(&result, starting_block_number);
  
  while (!done)
    ;
  printf("%d\n", result);
  return 0;
}
