//
// This is the solution to CPSC 213 Assignment 10.
// Do not share this code or any portion of it with anyone in any way.
// Do not remove this comment.
//

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "uthread.h"
#include "uthread_mutex_cond.h"

int num_threads;
uthread_t *threads;

uthread_mutex_t mutex;
uthread_cond_t cond;
int arrived_threads = 0;

void randomStall() {
  usleep(random() % 300000);
}

void waitForAllOtherThreads() {
  uthread_mutex_lock(mutex);
  arrived_threads++;
  if(arrived_threads == num_threads) {
    uthread_cond_broadcast(cond);
  } else {
    uthread_cond_wait(cond);
  }
  uthread_mutex_unlock(mutex);
}

void *p(void *v) {
  randomStall();
  printf("a\n");
  waitForAllOtherThreads();
  printf("b\n");
  return NULL;
}

int main(int argc, char **argv) {
  uthread_init(4);
  if(argc > 2) {
    printf("Usage: %s [number of threads]\n", argv[0]);
    exit(EXIT_FAILURE);
  }
  if(argc == 2) {
    num_threads = atoi(argv[1]);
  } else {
    num_threads = 3;
  }
  threads = malloc(num_threads * sizeof(uthread_t));

  mutex = uthread_mutex_create();
  cond = uthread_cond_create(mutex);

  for (int i=0; i<num_threads; i++)
    threads[i] = uthread_create(p, NULL);
  for (int i=0; i<num_threads; i++)
    uthread_join(threads[i], NULL);

  printf("------\n");

  uthread_cond_destroy(cond);
  uthread_mutex_destroy(mutex);
  free(threads);
}
