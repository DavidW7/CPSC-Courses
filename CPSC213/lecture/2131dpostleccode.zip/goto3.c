#include <stdio.h>

/* Another demonstration of what you can do with goto in C.

Here, a goto statement jumps into the middle of a loop before the loop
has been initialized, resulting in the code printing out an uninitialized
`i` variable. The output will differ depending on your platform, and the
loop may or may not run for a few iterations depending on that random
value of `i`.

The compiler will normally issue a warning if you do this, which you should
definitely pay attention to.

You can ask the compiler for more warnings by adding the "-Wall" flag -
that flag can save you a lot of debugging headaches.
*/

int main() {
	goto what;
	for(int i=0; i<10; i++) {
	what:
		printf("%d\n", i);
	}
}
