#include <stdio.h>

/* A demonstration of how we can turn a for loop into goto code. */

void for_version() {
  /* A simple for loop which prints out the numbers 0-9 */
  int i;
  for(i=0; i<10; i++) {
    printf("%d ", i);
  }
  printf("\n");
}

void goto_version() {
  /* The same for loop as above, but implemented using goto */
  int i;
  i = 0;
loop:
  if(i >= 10) goto done;
  printf("%d ", i);
  i++;
  goto loop;
done:
  /* Note: a label must always be followed by a statement. If there's
  nothing more to do, you can use a semicolon by itself, like this:
  
  done:
    ;
  */
  printf("\n");
}

int main() {
  /* Call the for loop version, and then the goto version, and show they do the same thing. */
  for_version();
  goto_version();
}
