/* This is the translation of rev1.s to C. */
int a[];
int j;
int x;

/* This code counts the number of elements in an array (between a[0] and a[j-1]) that are odd. */

int i; // r0
x = 0;
for(i = 0; j != 0; j--, i++) {
	if((a[i] & 1) != 0) {
		x += 1;
	}
}
