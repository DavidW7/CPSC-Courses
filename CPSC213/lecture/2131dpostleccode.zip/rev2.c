/* This is the translation of rev2.s to C. */
int x[];
/* y and z are actually used as constants - so they are not static variables. */
/* In the real assembly, you'd see something like

ld $123, r4
ld $456, r5

instead of

ld $y, r4
ld $z, r5
*/
#define y 123
#define z 456

/* This code counts the number of elements in an array (between x[0] and x[y-1]) equal to z. */
int r0 = 0;
for(int r1=0; r1 != y; r1++) {
	if(x[r1] == z)
		r0++;
}
