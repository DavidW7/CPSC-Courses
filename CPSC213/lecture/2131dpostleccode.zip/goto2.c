#include <stdio.h>

/* A demonstration of what you can do with goto in C.

Here, a goto statement jumps into the middle of a loop, creating an
infinite loop. Every time the for loop tries to exit, the goto will
jump back into the for loop.
*/

int main() {
	int i;
	for(i=0; i<10; i++) {
	what:
		printf("%d\n", i);
	}
	goto what;
}
