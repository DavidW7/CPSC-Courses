#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Demonstrate what can happen when you have a buffer overflow bug, triggered by the non-length-checked strcpy function.

Run this program using "./overflow $'AAAAAAAAAAAAAAAA\x01'" to trigger the bug and get a shell.

/* A simple structure to hold information about a user */
struct user {
	char name[16];
	int authenticated;
};

int main(int argc, char **argv) {
	/* Allocate our structure in memory */
	struct user user;
	/* Make sure they're not authenticated */
	user.authenticated = 0;
	/* BUG: strcpy doesn't check the length of the destination, and argv[1] is untrusted input from the user that could be any size */
	strcpy(user.name, argv[1]);
	/* We set user.authenticated to 0 above, but the overflow can overwrite it! */
	if(user.authenticated == 1) {
		printf("Wow, welcome back admin %s! Have a shell!\n", user.name);
		/* Customarily, an attacker's goal is to obtain a shell, which gives them full interactive control over a computer. */
		system("/bin/bash -i");
	} else {
		printf("Hello %s, you're not authenticated.\n", user.name);
	}
}
