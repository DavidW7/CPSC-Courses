#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Demonstrate what can happen when you have a use-after-free bug.

Run this program under valgrind (valgrind ./badfree) to reveal the bug (an invalid write to free'd memory).
*/
int main() {
	int *a = malloc(32);
	int *b = malloc(32);
	printf("a=%p b=%p\n", a, b);
	free(a);
	/*
	This next line only works on Linux (with the glibc C library).
	It writes to memory that has been freed, but in a specific way that subtly corrupts the heap.
	After this corruption, malloc starts returning the same pointer over and over again.
	This value would need to be adjusted for different computers or operating systems,
		something an attacker could do by fingerprinting the target system.
	On my Linux machine (which I showed in class) the next line was "a[0] = a - 4".
	For newer versions of Linux, including students.cs, "a[0] = a" works.

	Generally speaking, if you're lucky a use-after-free bug will just result in a crash, which
	you can debug easily.
	But if you're unlucky, use-after-free bugs can subtly break your program.
	*/
	a[0] = a;
	// The next few mallocs will all return the same address! Heap corruption!
	int *c = malloc(32);
	printf("c=%p\n", c);
	int *d = malloc(32);
	printf("d=%p\n", d);
	int *e = malloc(32);
	printf("e=%p\n", e);
}
