#include <stdio.h>

/* This program demonstrates size and alignment of structures.

Every structure has a size, and an alignment, which are not necessarily the same.
Structure memory addresses are assigned sequentially, aligning each field as necessary. */

/* Struct Y - size 3, alignment 1 */
struct Y {
	char a;
	char b;
	char c;
};
/* Struct X - size 12, alignment 4 (32-bit programs, -m32)
   Struct X - size 24, alignment 8 (64-bit programs, -m64)
*/
struct X {
	int a;
	int *b;
	int c;
};
/* Struct Z - size 36, alignment 4 (32-bit programs)
   Struct Z - size 64, alignment 8 (64-bit programs)
*/
struct Z {
	struct Y y0;
	struct Y y1;
	struct Y y2;
	struct X x0;	
	struct X x1;	
};
#include <stddef.h>
int main() {
	/* sizeof(X) - get the size of a structure X
	   offsetof(X, y) - get the offset to field y of structure X (must include <stddef.h>)
	   _Alignof(X) - get the alignment of a structure X (must compile with -std=gnu11)
	*/
	printf("X: size=%zd align=%zd\n", sizeof(struct X), _Alignof(struct X));
	printf("Y: size=%zd align=%zd\n", sizeof(struct Y), _Alignof(struct Y));
	printf("Z: size=%zd align=%zd\n", sizeof(struct Z), _Alignof(struct Z));
	printf("Z.y0 offset=%zd\n", offsetof(struct Z, y0));
	printf("Z.y1 offset=%zd\n", offsetof(struct Z, y1));
	printf("Z.y2 offset=%zd\n", offsetof(struct Z, y2));
	printf("Z.x0 offset=%zd\n", offsetof(struct Z, x0));
	printf("Z.x1 offset=%zd\n", offsetof(struct Z, x1));
}
