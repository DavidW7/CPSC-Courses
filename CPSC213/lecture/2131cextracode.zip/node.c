#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "refcount.h"

/* This program demonstrates reference counting for memory management - and also reveals its limitations.

Run this program under valgrind (valgrind ./node) to show that it does not always free all of its memory.
*/

/* Our node structure, which stores a next pointer */
struct node {
	int value;
	struct node *next;
};
/* Constructor for the node structure, using refcounting */
struct node *node_new(int value) {
	struct node *node = rc_malloc(sizeof(struct node));
	node->value = value;
	node->next = NULL;
	return node;
}
/* Set the next pointer of a node structure, safely using refcounting */
void node_set_next(struct node *this, struct node *next) {
	if(this->next) {
		rc_free_ref(this->next);
		this->next = 0;
	}
	if(next) {
		rc_keep_ref(next);
		this->next = next;
	}
	// this->next = next; // the non-refcounting version - may result in a dangling pointer
}
/* Release a single reference to the node pointer */
void node_release(struct node *this) {
	/* BUG! Without a finalizer, as we discussed in class, we cannot
       know when it is safe to clean up the next pointer, and this
       will result in a reference leak (which leads to a memory leak)

       This is why real reference counting systems need finalizers.
    */
    // can't safely free_ref this->next here!
	// if(this->next)
	// 	rc_free_ref(this->next);
	rc_free_ref(this);
}
int main() {
	/* Create three simple nodes */
	struct node *a = node_new(0);
	struct node *b = node_new(1);
	struct node *c = node_new(2);
	/* Arrange the nodes in a cycle: a->next points to b, b->next points to c, c->next points back to a */
	node_set_next(a, b);
	node_set_next(b, c);
	node_set_next(c, a);
	/* BUG! If we try to release all our pointers now, we'll leave
	   a cycle of nodes in memory that *cannot be released*. We would
	   need *garbage collection* in order to clean them up.
	*/
	node_release(b);
	node_release(a);
	node_release(c);
}
