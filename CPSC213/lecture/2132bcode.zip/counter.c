/* Interesting example that demonstrates a race condition with a single integer.

In class, we wondered whether it would be safe to increment/decrement an integer
from multiple threads. This program conclusively demonstrates that it is NOT safe
to do so. When run, the program almost certainly prints out something other than
the expected value of 0, and the value it prints is probably quite random.

Synchronization is needed to make this program safe - you will do so in A10.
*/

#include <stdio.h>
#include <stdlib.h>
#include "uthread.h"

/* It doesn't really matter if this is volatile or not - the accesses are still
unsafe. */
volatile int counter = 0;

void *increment(void *arg) {
	for(int i=0; i<1000000; i++)
		counter++;
	return NULL;
}

void *decrement(void *arg) {
	for(int i=0; i<1000000; i++)
		counter--;
	return NULL;
}

int main() {
	uthread_init(2);
	uthread_t t1 = uthread_create(increment, NULL);
	uthread_t t2 = uthread_create(decrement, NULL);
	uthread_join(t1, NULL);
	uthread_join(t2, NULL);
	printf("%d\n", counter);
}
