/* Demonstration of atomic operations on integers (aside).

In class I mentioned that some systems have atomic operations. The C library
now (as of C11) ships with a library called stdatomic that implements some
atomic operations on integers. Atomic operations are operations that are
guaranteed not to conflict, even when done from multiple threads simultaneously.

We will discuss a fundamental atomic operation, xchg, in class on Tuesday. But,
in the meantime, enjoy this correctly-counting version of the counter.c program.
*/

#include <stdatomic.h>
#include <stdlib.h>
#include <stdio.h>
#include "uthread.h"

atomic_int counter = 0;

void *increment(void *arg) {
	for(int i=0; i<1000000; i++)
		atomic_fetch_add(&counter, 1);
	return NULL;
}

void *decrement(void *arg) {
	for(int i=0; i<1000000; i++)
		atomic_fetch_add(&counter, -1);
	return NULL;
}

int main() {
	uthread_init(2);
	uthread_t t1 = uthread_create(increment, NULL);
	uthread_t t2 = uthread_create(decrement, NULL);
	uthread_join(t1, NULL);
	uthread_join(t2, NULL);
	printf("%d\n", counter);
}
