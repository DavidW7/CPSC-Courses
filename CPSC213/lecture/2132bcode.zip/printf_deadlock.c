/* Short example to demonstrate how hard it is to write interrupt handlers.

Try running this program, then press Ctrl+C a few times to interrupt it. After
one or a few tries, the program should hang and stop printing anything. This
is caused by a deadlock when sigint interrupts printf. (You can press Ctrl+\,
i.e. Ctrl and the backslash key, to force-quit the program).

sigint is an interrupt handler - we use the signal() function to register it
as the handler for the SIGINT interrupt (which is sent when you press Ctrl+C).
It calls printf(), which is NOT an async-signal-safe function (i.e. it is not
safe to call from an interrupt handler). Therefore, if the handler happens to
interrupt one of main's calls to printf, it may end up *re-entering* printf
(calling printf from "within" printf) and causing a deadlock or crash.

The full list of async-signal-safe functions is listed here:
http://man7.org/linux/man-pages/man7/signal-safety.7.html
Although this list includes nearly 200 functions, the C library includes
thousands of functions that are NOT safe to call. Many popular functions
are missing from the safe list, including malloc, free, printf and sprintf.
This makes programming interrupt handlers quite challenging.
*/

#include <signal.h>
#include <unistd.h>
#include <stdio.h>

void sigint(int signo) {
  printf("Interrupted!\n");
}

int main() {
  signal(SIGINT, sigint);
  for(int i=0; ; i++) {
    for(int j=0; j<1000; j++)
      printf("");
    printf("%d", i % 10);
    fflush(stdout);
  }
}
