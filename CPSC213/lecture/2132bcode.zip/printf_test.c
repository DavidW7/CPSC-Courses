/* Quick demonstration of printf's buffering behaviour.

_exit(0) quits a program without flushing buffers (which
is what would happen in a crash). We try to write an I and O
to stdout, but both are swallowed. In contrast, writing E
to stderr works, because stderr is not buffered (by default).

If you uncomment the fflush, you should see "EIO" - because
the E from stderr will be output before the I and O from stdout
are flushed.
*/

#include <stdio.h>
#include <unistd.h>

int main() {
	printf("I");
	fprintf(stdout, "O");
	fprintf(stderr, "E");
//	fflush(stdout);
	_exit(0);
}
