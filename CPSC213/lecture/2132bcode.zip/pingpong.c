/* Extended version of the example ping-pong code shown in the slides.

This version has, by student request, three threads ping, pong and peng, which
print an I, O and E respectively.

The three threads are created in that order in main(); due to uthread's round-robin
scheduling, when main() blocks (via uthread_block or uthread_join) the threads
will run in that order (I, O, E) until they finish.

As a modification, we made pong and peng run for 200 iterations instead of just
100. We noted that, if main() only waits for ping (via either an explicit block
and unblock, or via uthread_join) before exiting, that we see 100 "IOE" outputs
followed by a trailing "OE". This is because main() is placed on the end of the
queue when ping() unblocks it (via explicit unblock or exit), giving pong and
peng each one more iteration to run before main() exits and kills everything.

You can play with this code yourself. Try experimenting with different numbers
of physical CPUs (the argument to uthread_init()) and see how the output changes.
Try changing main's uthread_block to a uthread_yield or uthread_join. Try having
different threads unblock main.
*/

#include <stdio.h>
#include <stdlib.h>
#include "uthread.h"

/* Handle for main()'s thread; this is filled in by main using uthread_self() */
uthread_t main_thread;

/* First thread function - prints a stream of I characters */
void *ping(void *arg) {
	for(int i=0; i<100; i++) {
		/* Notice that we need to flush stdout because the printf doesn't contain
		a newline; as discussed in class, printf is (by default) line-buffered. */
		printf("I"); fflush(stdout);
		/* Yielding here lets the next thread run, but puts this thread on the end
		of the ready queue so it gets to run again later. */
		uthread_yield();
	}
	/* An explicit unblock here (with main blocking) is basically the same
	as having main join this thread - in both cases, main blocks until this
	thread finishes.
	The main differences are that main doesn't get the return value, and
	this thread's TCB won't be freed. */
	uthread_unblock(main_thread);
	return NULL;
}

/* Second thread function - prints a stream of O characters */
void *pong(void *arg) {
	for(int i=0; i<200; i++) {
		printf("O"); fflush(stdout);
		uthread_yield();
	}
	return NULL;
}

/* Third thread function - prints a stream of E characters with a trailing space
(which improves the visibility of the output) */
void *peng(void *arg) {
	for(int i=0; i<200; i++) {
		printf("E "); fflush(stdout);
		uthread_yield();
	}
	return NULL;
}

int main() {
	/* With one processor, uthread uses perfect round-robin scheduling.
	With multiple processors, the scheduling gets more complex - it's still
	round-robin but threads may finish at different times on different cores. */
	uthread_init(1);
	main_thread = uthread_self();
	uthread_t t1 = uthread_create(ping, NULL);
	uthread_t t2 = uthread_create(pong, NULL);
	uthread_t t3 = uthread_create(peng, NULL);
	// because t1 calls unblock before exiting, this works like uthread_join(t1, NULL)
	uthread_block();
	// You can experiment with block vs. join here, or even use uthread_yield()
	// uthread_join(t1, NULL);
	// uthread_join(t2, NULL);
	// uthread_join(t3, NULL);
}
