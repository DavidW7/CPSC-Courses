int proc(int *a, int b) {
	if(b == 0) {
		return 0;
	}
BB0:
	r0 = proc(a, b-1);
	return r0 + a[b-1];
}
