/* A demonstration of printf's 'ability' to dump out stack memory indiscriminately,
and a demo of the fact that the stack is not cleared after a function exits. */

int secret() {
	/* Put a secret that should never be revealed onto the stack */
	char buf[128];
	strcpy(buf, "secret secret secret AAAAAAAAAAAAAAAAA sekrit");
	return 0;
}

int leaker2() {
	/* Leak out the secret by dumping the stack, which eventually reaches the stack of the caller 'leaker' */
	/* You'll see 4141414141 somewhere in the output - that corresponds to the AAAAAAA part in the secret. */
	/* When printf runs out of arguments, it'll just start taking arguments sequentially off the stack. */
	printf("Your secret in hex is somewhere here: %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx %llx\n", 1);
}

int leaker() {
	char fakebuf[128];
	/* Leak out the secret by printing out 'fakebuf', which overlaps with secret's buf */
	printf("Your secret is: %s\n", fakebuf);
	leaker2();
}

int main() {
	secret();
	leaker();
}
