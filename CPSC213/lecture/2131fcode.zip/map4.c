/* One possible way to implement map(). In this version, our add function takes the existing pointer (from the destination)
   and outputs a new pointer. */

#include <stdlib.h>
#include <stdio.h>

/* add2, returning a new element, but reusing the existing definition if possible. */
void *add2(void *av, void *bv, void *dv) {
	int *a = av;
	int *b = bv;
	int *d = dv;
	if(d == NULL) {
		d = malloc(sizeof(int));
	}
	*d = *a + *b;
	return d;
}

void map(void *(*f)(void*, void*, void *), int n, void** s0, void** s1, void** d) {
	for(int i=0; i<n; i++) {
		d[i] = f(s0[i], s1[i], d[i]);
	}
}

int main() {
	int a[] = {1, 2, 3};
	int *ap[] = {a, a+1, a+2};
	int b[] = {4, 5, 6};
	int *bp[] = {b, b+1, b+2};
	int d[3];
	int *dp[] = {d, d+1, d+2};

	map(add2, 3, (void **)ap, (void **)bp, (void **)dp);
	for(int i=0; i<3; i++) {
		printf("%d\n", *dp[i]);
	}

	int *ep[3] = {0, 0, 0};
	map(add2, 3, (void **)ap, (void **)dp, (void **)ep);
	for(int i=0; i<3; i++) {
		printf("%d\n", *ep[i]);
		free(ep[i]);
	}
}
