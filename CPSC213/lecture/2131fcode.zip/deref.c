#include <stdio.h>
/* A demonstration of what might happen when you pass an incompatible object to a function taking void *.

This program compiles with no warnings or errors on "gcc -Wall -std=gnu11 deref.c -o deref", but prints
out garbage from the stack at runtime.
*/

/* Structure definition for an A "instance" */
struct A {
	void *class;
	int i;
};
/* A member function of A that should only be passed A instances */
void A_ping(void *av) {
	struct A *a = av;
	/* We can access "a->i" even though a is a pointer to int.
	   This just grabs some random data off the stack. */
	printf("a->i = %d\n", a->i);
}
int main() {
	int c = 12345;
	A_ping(&c);
}
