/* One possible way to implement map(). In this version, our add function takes an explicit destination parameter. */

#include <stdlib.h>
#include <stdio.h>

/* add2, explicit destination parameter. Allows us to write into existing memory if it's available, saving malloc.
   This is a bit more verbose than other alternatives, though. */
void add2(void *av, void *bv, void **dv) {
	int *a = av;
	int *b = bv;
	int **d = (int **)dv;
	if(*d == NULL) {
		*d = malloc(sizeof(int));
	}
	**d = *a + *b;
}

void map(void (*f)(void*, void*, void**), int n, void** s0, void** s1, void** d) {
	for(int i=0; i<n; i++) {
		f(s0[i], s1[i], &d[i]);
	}
}

int main() {
	int a[] = {1, 2, 3};
	int *ap[] = {a, a+1, a+2};
	int b[] = {4, 5, 6};
	int *bp[] = {b, b+1, b+2};
	int d[3];
	int *dp[] = {d, d+1, d+2};

	map(add2, 3, (void **)ap, (void **)bp, (void **)dp);
	for(int i=0; i<3; i++) {
		printf("%d\n", d[i]);
	}

	int *ep[3] = {0, 0, 0};
	map(add2, 3, (void **)ap, (void **)dp, (void **)ep);
	for(int i=0; i<3; i++) {
		printf("%d\n", *ep[i]);
		free(ep[i]);
	}
}
