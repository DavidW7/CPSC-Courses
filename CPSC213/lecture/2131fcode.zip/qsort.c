/* A demonstration of how to use qsort. */
#include <stdlib.h>

/* Compare two integers and return -1, 0, or 1 depending on the result */
int cmp_int(const void *av, const void *bv) {
	int a = *(int *)av;
	int b = *(int *)bv;
	if(a<b) return -1;
	if(a==b) return 0;
	return 1;
}

int main() {
	/* Use qsort to sort this array of numbers */
	int arr[] = {3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 8, 9, 7, 9};
	int arrlen = sizeof(arr)/sizeof(arr[0]);
	qsort(arr, arrlen, sizeof(int), cmp_int);
	for(int i=0; i<arrlen; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
}
