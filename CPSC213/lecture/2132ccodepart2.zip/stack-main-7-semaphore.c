/* Synchronized version of the stack code that uses semaphores to synchronize the two threads.

See Tuesday's code (Aug 6) - this is an extension off the code from that lecture.

Compile with

gcc -std=gnu11 stack-main-7-semaphore.c uthreads/uthread.c uthreads/uthread_sem.c -I uthreads -o stack-main
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "stack.c"
#include "uthread.h"
#include "uthread_sem.h"

/* This semaphore is used as a counter to count the number of unclaimed elements in the stack. */
uthread_sem_t sem;
/* This semaphore is used as a simple mutex to protect the stack structure. */
uthread_sem_t mutex;

#define ITERATIONS 200

void *pusher(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    /* Push an element, and signal that a new unclaimed element is available */
    uthread_sem_wait(mutex);
    push(element_new(i));
    uthread_sem_signal(sem);
    uthread_sem_signal(mutex);
  }
  return NULL;
}

void *popper(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    struct element *e = NULL;
    /* Wait to claim an element (by decrementing the sem counter).
    Once we've "claimed" an element this way, it will be safe to pop a single element. */
    uthread_sem_wait(sem);
    uthread_sem_wait(mutex);
    e = pop();
    uthread_sem_signal(mutex);
    printf("%d ", e->value);
    fflush(stdout);
    free(e);
  }
  return NULL;
}

int main() {
  uthread_init(4);
  sem = uthread_sem_create(0);
  mutex = uthread_sem_create(1);
  uthread_t t1 = uthread_create(pusher, NULL);
  uthread_t t2 = uthread_create(popper, NULL);
  uthread_t t3 = uthread_create(pusher, NULL);
  uthread_t t4 = uthread_create(popper, NULL);
  uthread_join(t1, NULL);
  uthread_join(t2, NULL);
  uthread_join(t3, NULL);
  uthread_join(t4, NULL);
  uthread_sem_destroy(mutex);
  uthread_sem_destroy(sem);
  return 0;
}
