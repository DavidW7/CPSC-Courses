/* Demonstration of synchronization in Java - built into every single Object in the language! */
class JavaSynchronization {
  static Integer obj = new Integer(0);
  public static final void main(String[] args) throws Throwable {
    Thread t = new Thread() { public void run() { 
      try {
        /* This thread will try to notify the main thread to wake up its obj.wait() */
        while(true) {
          System.out.println("notifying");
          Thread.sleep(100);
          synchronized(obj) {
            obj.notify();
          }
        }
      } catch(InterruptedException e) {

      }
    }};
    /* setDaemon tells Java not to wait for this thread on exit */
    t.setDaemon(true);
    t.start();
    synchronized(obj) {
      /* This thread will go to sleep waiting on obj (acting as a condition variable) */
      System.out.println("hi");
      obj.wait();
      /* Objects acting as condition variables also have notify (signal) and notifyAll (broadcast) methods */
      obj.notify();
      obj.notifyAll();
    }
  }
}
