public class Stack {
  public static class Element {
    public int value;
    Element next;
    public Element(int value) {
      this.value = value;
      this.next = null;
    }
  }

  private Element top;

  void push(Element e) {
    e.next = top;
    top = e;
  }

  Element pop() {
    Element e = top;
    if(top != null)
      top = top.next;
    return e;
  }
}
