/* Correctly synchronized version of main stack driver.

This version uses mutexes. 

Compile with

gcc -std=gnu11 stack-main-4-mutex.c uthreads/uthread.c uthreads/uthread_mutex_cond.c -I uthreads -o stack-main
*/

#include "stack.c"
#include "uthread_mutex_cond.h"
#include <unistd.h>

uthread_mutex_t mutex; // ADDED

#define ITERATIONS 200

void *pusher(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    uthread_mutex_lock(mutex);    // ADDED
    push(element_new(i));
    uthread_mutex_unlock(mutex);  // ADDED
    usleep(100000); // ADDED: Simulate some work
  }
  return NULL;
}

void *popper(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    struct element *e = NULL;
    while(e == NULL) {
      /* We repeatedly try to grab an element here.
      This is safe and correct, but inefficient if elements aren't always available.
      In the next version, we'll use condition variables to make this nicer.
      */
      uthread_mutex_lock(mutex);    // ADDED
      e = pop();
      uthread_mutex_unlock(mutex);  // ADDED
    }
    printf("%d ", e->value);
    fflush(stdout);
    free(e);
  }
  return NULL;
}

int main() {
  uthread_init(2);
  mutex = uthread_mutex_create(); // ADDED
  uthread_t t1 = uthread_create(pusher, NULL);
  uthread_t t2 = uthread_create(popper, NULL);
  uthread_join(t1, NULL);
  uthread_join(t2, NULL);
  uthread_mutex_destroy(mutex); // ADDED
  return 0;
}
