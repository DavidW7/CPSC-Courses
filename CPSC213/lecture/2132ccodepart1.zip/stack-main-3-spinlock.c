/* Correctly synchronized version of main stack driver.

This version uses the spinlocks provided by the uthreads library. It's basically
just a demonstration of how you use that library.

Compile with

gcc -std=gnu11 stack-main-3-spinlock.c uthreads/uthread.c -I uthreads -o stack-main
*/

#include "stack.c"
#include "spinlock.h"

#define ITERATIONS 200

spinlock_t spinlock;

void *pusher(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    spinlock_lock(&spinlock);
    push(element_new(i));
    spinlock_unlock(&spinlock);
  }
  return NULL;
}

void *popper(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    struct element *e = NULL;
    while(e == NULL) {
      spinlock_lock(&spinlock);
      e = pop();
      spinlock_unlock(&spinlock);
    }
    printf("%d ", e->value);
    fflush(stdout);
    free(e);
  }
  return NULL;
}

int main() {
  uthread_init(2);
  spinlock_create(&spinlock); // ADDED
  uthread_t t1 = uthread_create(pusher, NULL);
  uthread_t t2 = uthread_create(popper, NULL);
  uthread_join(t1, NULL);
  uthread_join(t2, NULL);
  return 0;
}
