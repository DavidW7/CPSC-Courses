/* Unsynchronized version of main stack driver.

This will occasionally crash or hang because of a race between push() and pop().

Compile with

gcc -std=gnu11 stack-main-0-unsync.c uthreads/uthread.c -I uthreads -o stack-main
*/

#include "stack.c"

#define ITERATIONS 200

void *pusher(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    push(element_new(i));
    uthread_yield(); // yield needed for uthread_init(1);
  }
  return NULL;
}

void *popper(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    struct element *e = NULL;
    while(e == NULL) {
      e = pop();
      uthread_yield();
    }
    printf("%d ", e->value);
    fflush(stdout);
    free(e);
  }
  return NULL;
}

int main() {
  /* This program works fine with uthread_init(1) but fails with uthread_init(2). */
  uthread_init(2);
  uthread_t t1 = uthread_create(pusher, NULL);
  uthread_t t2 = uthread_create(popper, NULL);
  uthread_join(t1, NULL);
  uthread_join(t2, NULL);
  return 0;
}
