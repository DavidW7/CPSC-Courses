/* Correctly synchronized version of main stack driver.

This version uses atomics provided by the C language to implement a working spinlock.

Compile with

gcc -std=gnu11 stack-main-2-spinlock.c uthreads/uthread.c -I uthreads -o stack-main
*/

#include "stack.c"

/* Second attempt at making a spinlock.

This version correctly uses an atomic exchange operation to implement spinlocks. */
#include <stdatomic.h>

typedef atomic_int spinlock_t;

void lock(spinlock_t *spinlock) {
  while(1) {
    /* This while(*spinlock) ; loop is an optimization to avoid repeatedly using the
       expensive atomic exchange when the lock is held by another thread. */
    while(*spinlock)
      ;
    int prev = atomic_exchange(spinlock, 1); // ADDED
    if(!prev)
      break;
  }
}

void unlock(spinlock_t *spinlock) {
  *spinlock = 0;
}

#define ITERATIONS 200

spinlock_t spinlock;

void *pusher(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    lock(&spinlock);
    push(element_new(i));
    unlock(&spinlock);
  }
  return NULL;
}

void *popper(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    struct element *e = NULL;
    while(e == NULL) {
      lock(&spinlock);
      e = pop();
      unlock(&spinlock);
    }
    printf("%d ", e->value);
    fflush(stdout);
    free(e);
  }
  return NULL;
}

int main() {
  uthread_init(2);
  uthread_t t1 = uthread_create(pusher, NULL);
  uthread_t t2 = uthread_create(popper, NULL);
  uthread_join(t1, NULL);
  uthread_join(t2, NULL);
  return 0;
}
