/* Synchronized version of the stack code that INCORRECTLY uses condition variables to wait for elements to be available.

This version uses mutexes and condition variables together to wait for elements to be available.

Compile with

gcc -std=gnu11 stack-main-5-badcond.c uthreads/uthread.c uthreads/uthread_mutex_cond.c -I uthreads -o stack-main
*/

#include "stack.c"
#include "uthread_mutex_cond.h"
#include <unistd.h>

uthread_mutex_t mutex;
uthread_cond_t available_cond;  // ADDED

#define ITERATIONS 200

void *pusher(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    uthread_mutex_lock(mutex);
    push(element_new(i));
    uthread_cond_signal(available_cond);  // ADDED
    uthread_mutex_unlock(mutex);
    usleep(100000);
  }
  return NULL;
}

void *popper(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    struct element *e = NULL;
    /*
    We use an "if" test here under the mistaken assumption that, if this thread gets
    a signal, an element must be available. In fact, it is possible for a second
    pusher thread to run and grab the new element in between this thread being
    unblocked and this thread locking the mutex and running again.
    */
    uthread_mutex_lock(mutex);
    e = pop();
    if(e == NULL) {
      uthread_cond_wait(available_cond);  // ADDED
      e = pop();
    }
    uthread_mutex_unlock(mutex);
    printf("%d ", e->value);
    fflush(stdout);
    free(e);
  }
  return NULL;
}

int main() {
  uthread_init(2);
  mutex = uthread_mutex_create();
  available_cond = uthread_cond_create(mutex);
  uthread_t t1 = uthread_create(pusher, NULL);
  uthread_t t2 = uthread_create(popper, NULL);
  uthread_t t3 = uthread_create(pusher, NULL);
  uthread_t t4 = uthread_create(popper, NULL);
  uthread_join(t1, NULL);
  uthread_join(t2, NULL);
  uthread_join(t3, NULL);
  uthread_join(t4, NULL);
  return 0;
}
