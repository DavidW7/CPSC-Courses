/* Simple example of a race in Java, demonstrating that races are not limited to just C.

To be correct, this program requires synchronization. */

public class StackMain {
  private static final int ITERATIONS = 500;
  private static Stack stack;

  static void pusher() {
    System.out.println("Pusher running");
    for(int i=0; i<ITERATIONS; i++) {
      stack.push(new Stack.Element(i));
    }
    System.out.println("Pusher's done!");
  }

  static void popper() {
    System.out.println("Popper running");
    for(int i=0; i<ITERATIONS; i++) {
      Stack.Element e = null;
      while(e == null)
        e = stack.pop();
      System.out.print(e.value + " ");
    }
    System.out.println("Popper's done!");
  }

  public static void main(String[] args) throws Exception {
    stack = new Stack();

    Thread t1 = new Thread() { public void run() { pusher(); } };
    Thread t2 = new Thread() { public void run() { popper(); } };
    t1.start();
    t2.start();
    t1.join();
    t2.join();
    System.out.println();
  }
}
