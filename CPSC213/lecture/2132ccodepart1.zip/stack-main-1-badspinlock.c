/* Badly synchronized version of main stack driver.

This will occasionally crash or hang because of a race in the spinlock.

Compile with

gcc -std=gnu11 stack-main-1-badspinlock.c uthreads/uthread.c -I uthreads -o stack-main
*/

#include "stack.c"

/* First attempt at making a spinlock */
typedef volatile int spinlock_t;

/* This spinlock does not work - there's still a possibility of a race. */
void lock(spinlock_t *spinlock) {
  while(*spinlock)
    ;
  /* For example, at this point, a second thread could get through here,
     lock it, and then both this thread and the other thread would be holding
     the lock simultaneously. */
  *spinlock = 1;
}

void unlock(spinlock_t *spinlock) {
  *spinlock = 0;
}

#define ITERATIONS 200

spinlock_t spinlock;

void *pusher(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    lock(&spinlock);      // ADDED
    push(element_new(i));
    unlock(&spinlock);    // ADDED
  }
  return NULL;
}

void *popper(void *arg) {
  for(int i=0; i<ITERATIONS; i++) {
    struct element *e = NULL;
    while(e == NULL) {
      lock(&spinlock);      // ADDED
      e = pop();
      unlock(&spinlock);    // ADDED
    }
    printf("%d ", e->value);
    fflush(stdout);
    free(e);
  }
  return NULL;
}

int main() {
  uthread_init(2);
  uthread_t t1 = uthread_create(pusher, NULL);
  uthread_t t2 = uthread_create(popper, NULL);
  uthread_join(t1, NULL);
  uthread_join(t2, NULL);
  return 0;
}
