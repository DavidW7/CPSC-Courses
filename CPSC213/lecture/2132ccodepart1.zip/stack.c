#include <stdlib.h>
#include <stdio.h>
#include "uthread.h"

struct element {
  int value;
  struct element *next;
};

struct element *element_new(int value) {
  struct element *e = malloc(sizeof(*e));
  e->value = value;
  e->next = NULL;
  return e;
}

struct element *top = NULL;

void push(struct element *e) {
  e->next = top;
  top = e;
}

struct element *pop() {
  struct element *e = top;
  if(top != NULL)
    top = top->next;
  return e;
}
